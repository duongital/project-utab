import"./modulepreload-polyfill-B5Qt9EMX.js";import{j as t,c as n}from"./client-HuVQoHq8.js";function r(){return t.jsx("div",{className:"container",children:"Options"})}function e(){const o=document.querySelector("#__root");if(!o)throw new Error("Can't find Options root element");n.createRoot(o).render(t.jsx(r,{}))}e();
//# sourceMappingURL=index.html-Bkz4baWf.js.map
