console.log("background script loaded");
//# sourceMappingURL=index.ts-Chl-eaRG.js.map
