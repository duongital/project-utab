console.log("background script loaded");
